package poo.labo02;

public class SpellPracticeSession {
	//TODO: déclarer le tableau de sorciers

	//TODO: déclarer le tableau de sortilèges
	
	public String[] getWizardNames() {
		//TODO : complète-moi
		return null;
	}
	
	public String[] getSpellNames() {
		//TODO : complète-moi
		return null;
	}
	
	public String[] practice(int wizardIndex, int spellIndex) {
		//TODO : complète-moi
		return null;
	}
}
